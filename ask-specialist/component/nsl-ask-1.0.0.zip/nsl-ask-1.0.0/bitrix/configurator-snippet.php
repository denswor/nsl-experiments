<?php
/**
 * nsl-ask — mount snippet for the configurator page (EXAMPLE).
 * Put at the end of the configurator component template (template.php), after the page markup.
 * $arResult['MODEL'] and the summary markup are placeholders: wire them to the real component data.
 */
?>
<script src="<?= SITE_TEMPLATE_PATH ?>/js/nsl-ask.min.js" defer></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    window.nslAsk = NSLAsk.mount({
      endpoint: '/ajax/ask-specialist.php',
      extraFields: { sessid: BX.bitrix_sessid() },
      privacyUrl: '/privacy/',
      // Read on every open, so the request always carries the build as it is right now.
      build: function () {
        var total = document.querySelector('[data-config-total]');     // placeholder selectors
        var rows = document.querySelectorAll('[data-block]');            // summary items, as on the live page
        var lines = Array.prototype.map.call(rows, function (r) {
          return { section: r.getAttribute('data-block'), value: (r.querySelector('[data-value]') || r).textContent.trim() };
        });
        return {
          title: <?= json_encode((string)$arResult['MODEL'], JSON_UNESCAPED_UNICODE) ?>,
          meta: total ? total.textContent.trim() : '',
          lines: lines
        };
      }
    });
  });
</script>
<?php
/*
 * Triggers, in the section header template:
 *   <a href="#" class="cfg-stuck" data-nsl-ask data-nsl-ask-area="storage" data-nsl-ask-from="Drive cage">Stuck here?</a>
 * Under the summary, instead of the old "Configure assistance" popup link:
 *   <a href="#" data-nsl-ask>Not sure? Ask a specialist</a>
 */
