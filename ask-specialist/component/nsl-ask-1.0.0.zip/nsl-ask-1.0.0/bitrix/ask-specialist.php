<?php
/**
 * nsl-ask — request endpoint (EXAMPLE / starting point, adapt to the project).
 * Place at /ajax/ask-specialist.php and pass `endpoint: '/ajax/ask-specialist.php'` and
 * `extraFields: { sessid: BX.bitrix_sessid() }` to NSLAsk.mount().
 *
 * Request: POST multipart/form-data
 *   message  — free text (may be empty when a file is attached)
 *   file     — optional attachment (one file, up to 10 MB on the client)
 *   areas    — comma-separated problem areas: cpu,ram,storage,gpu,net,power,compat,budget
 *   budget   — "$10–20k" or "none"
 *   name, email, phone
 *   channel  — phone | email | whatsapp
 *   timing   — today | norush
 *   from     — configurator section the form was opened from ("Drive cage"), may be empty
 *   build    — JSON: { title, meta, lines? } as passed to the `build` option
 *   page     — URL of the page
 *   sessid   — Bitrix CSRF token
 *   website  — honeypot, must be empty (the client never sends a filled one)
 * Response: 2xx = success (body ignored), anything else = the form shows "Couldn't send. Please try again."
 */

use Bitrix\Main\Application;
use Bitrix\Main\Mail\Event;

define('NO_KEEP_STATISTIC', true);
define('NOT_CHECK_PERMISSIONS', true);
require $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

header('Content-Type: application/json; charset=utf-8');

function fail($code, $error) { http_response_code($code); echo json_encode(['ok' => false, 'error' => $error]); exit; }

$request = Application::getInstance()->getContext()->getRequest();
if (!$request->isPost() || !check_bitrix_sessid()) fail(403, 'forbidden');
if ((string)$request->getPost('website') !== '') { http_response_code(200); echo json_encode(['ok' => true]); exit; }

$p = function ($k, $max = 500) use ($request) { return mb_substr(trim((string)$request->getPost($k)), 0, $max); };
$message = $p('message', 10000);
$name    = $p('name', 200);
$email   = $p('email', 200);
$phone   = $p('phone', 50);
$channel = in_array($p('channel'), ['phone', 'email', 'whatsapp'], true) ? $p('channel') : 'phone';
$timing  = in_array($p('timing'), ['today', 'norush'], true) ? $p('timing') : 'norush';
$areas   = array_values(array_intersect(explode(',', $p('areas')), ['cpu', 'ram', 'storage', 'gpu', 'net', 'power', 'compat', 'budget']));
$budget  = $p('budget', 50);
$from    = $p('from', 100);
$page    = $p('page', 500);
$build   = json_decode((string)$request->getPost('build'), true) ?: [];

$file = $request->getFile('file');
$hasFile = is_array($file) && ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK;

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) fail(400, 'contact');
if ($channel !== 'email' && strlen(preg_replace('/\D/', '', $phone)) < 6) fail(400, 'phone');
if ($message === '' && !$hasFile) fail(400, 'empty');

$fileId = null;
if ($hasFile) {
    if ($file['size'] > 10 * 1024 * 1024) fail(413, 'file_too_large');
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['pdf', 'xls', 'xlsx', 'csv', 'doc', 'docx', 'txt', 'png', 'jpg', 'jpeg', 'webp', 'heic', 'gif'], true)) fail(415, 'file_type');
    $fileId = CFile::SaveFile(array_merge($file, ['MODULE_ID' => 'main']), 'ask-specialist');
}

// TODO: rate-limit by IP / email (e.g. 5 requests per 10 minutes).
// TODO: store the lead (CRM / highload block / form result) and route it: `from` and `areas` say which specialist should take it.
// Example: mail event type "NSL_ASK_SPECIALIST" created in the admin panel, with a template for the sales team.
Event::send([
    'EVENT_NAME' => 'NSL_ASK_SPECIALIST',
    'LID'        => SITE_ID,
    'C_FIELDS'   => [
        'NAME'    => $name,
        'EMAIL'   => $email,
        'PHONE'   => $phone,
        'CHANNEL' => $channel,
        'TIMING'  => $timing,
        'MESSAGE' => $message,
        'AREAS'   => implode(', ', $areas),
        'BUDGET'  => $budget === 'none' ? 'No fixed budget' : $budget,
        'FROM'    => $from,
        'BUILD'   => trim(($build['title'] ?? '') . ' · ' . ($build['meta'] ?? ''), ' ·'),
        'PAGE'    => $page,
    ],
    'FILE'       => $fileId ? [$fileId] : [],
]);

http_response_code(200);
echo json_encode(['ok' => true]);
