<?php
/**
 * nsl-dotw — mount snippet for the site template footer (EXAMPLE).
 * Put before </body> in /local/templates/nsl/footer.php.
 *
 * Assumes the current deal comes from an infoblock "Deal of the Week" (code DOTW) with properties:
 *   DEAL_ID (string), MODEL, TAGLINE (multiple), USES, IMAGE (file, transparent PNG/WebP), ACTIVE_FROM / ACTIVE_TO.
 * Adjust to the real data source.
 */

// Do not show on cart, checkout and account pages
$dotwSkip = CSite::InDir('/personal/') || CSite::InDir('/cart/') || CSite::InDir('/order/');

$dotw = null;
if (!$dotwSkip && \Bitrix\Main\Loader::includeModule('iblock')) {
    $res = CIBlockElement::GetList(
        ['ACTIVE_FROM' => 'DESC'],
        ['IBLOCK_CODE' => 'DOTW', 'ACTIVE' => 'Y', 'ACTIVE_DATE' => 'Y'],
        false,
        ['nTopCount' => 1],
        ['ID', 'IBLOCK_ID', 'NAME', 'PROPERTY_DEAL_ID', 'PROPERTY_MODEL', 'PROPERTY_USES', 'PROPERTY_IMAGE']
    );
    if ($row = $res->Fetch()) { // Fetch, not GetNext: the component escapes HTML itself
        $tagline = [];
        $t = CIBlockElement::GetProperty($row['IBLOCK_ID'], $row['ID'], [], ['CODE' => 'TAGLINE']);
        while ($p = $t->Fetch()) { if ($p['VALUE'] !== '') $tagline[] = $p['VALUE']; }

        $dotw = [
            'dealId'      => (string)$row['PROPERTY_DEAL_ID_VALUE'],
            'title'       => (string)$row['PROPERTY_MODEL_VALUE'],
            'tagline'     => $tagline,
            'uses'        => (string)$row['PROPERTY_USES_VALUE'],
            'image'       => ['src' => CFile::GetPath($row['PROPERTY_IMAGE_VALUE']), 'alt' => (string)$row['PROPERTY_MODEL_VALUE']],
            'endpoint'    => '/ajax/dotw-claim.php',
            'extraFields' => ['sessid' => bitrix_sessid()],
            'privacyUrl'  => '/privacy/',
        ];
    }
}

if ($dotw && $dotw['dealId'] !== ''): ?>
<div id="nsl-dotw"></div>
<script src="<?= SITE_TEMPLATE_PATH ?>/js/nsl-dotw.min.js?v=1.0.0" defer></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    if (window.NSLDotw) NSLDotw.mount('#nsl-dotw', <?= json_encode($dotw, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?>);
  });
</script>
<?php endif; ?>
