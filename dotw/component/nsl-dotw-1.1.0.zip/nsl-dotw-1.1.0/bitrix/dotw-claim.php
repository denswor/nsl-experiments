<?php
/**
 * nsl-dotw — claim endpoint (EXAMPLE / starting point, adapt to the project).
 * Place at /ajax/dotw-claim.php and pass `endpoint: '/ajax/dotw-claim.php'` and
 * `extraFields: { sessid: BX.bitrix_sessid() }` to NSLDotw.mount().
 *
 * Request: POST application/x-www-form-urlencoded
 *   email   — visitor's email
 *   dealId  — deal id, e.g. "2026-w44-r640"
 *   page    — URL the banner was on
 *   sessid  — Bitrix CSRF token
 * Response: 2xx = success (body ignored), anything else = the banner shows "Couldn't send. Please try again."
 */

use Bitrix\Main\Application;
use Bitrix\Main\Mail\Event;

define('NO_KEEP_STATISTIC', true);
define('NOT_CHECK_PERMISSIONS', true);
require $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

header('Content-Type: application/json; charset=utf-8');

$request = Application::getInstance()->getContext()->getRequest();
if (!$request->isPost() || !check_bitrix_sessid()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'forbidden']);
    exit;
}

$email  = trim((string)$request->getPost('email'));
$dealId = preg_replace('/[^a-z0-9\-_.]/i', '', (string)$request->getPost('dealId'));
$page   = mb_substr((string)$request->getPost('page'), 0, 500);

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $dealId === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'bad_request']);
    exit;
}

// TODO: rate-limit by IP / email (e.g. 5 requests per 10 minutes).
// TODO: store the lead (CRM / highload block / form result) together with $dealId and $page.
// TODO: send the deal email. Example with a mail event type "NSL_DOTW_CLAIM" created in the admin panel:
Event::send([
    'EVENT_NAME' => 'NSL_DOTW_CLAIM',
    'LID'        => SITE_ID,
    'C_FIELDS'   => [
        'EMAIL'   => $email,
        'DEAL_ID' => $dealId,
        'PAGE'    => $page,
    ],
]);

http_response_code(200);
echo json_encode(['ok' => true]);
